Nerdi Digi Nomad Company Webpage
This website showcase our services in digital marketing, creative design and call center operations to promote and market clients' product and services


Design Process
The website has to show clearly the different types of services NDN is offering to businesses. Having links to various parts of the website, as well as information enables the viewer to have a clearer picture.

The carousel showcase all the 3 types of services NDN is offering. Contact us page enable interested parties to contact NDN by submitting a form. Contact details like operating hours, phone number and social media accounts are readily available at the bottom of each page


Features
Different parts of the websites contains information about the company. It's servces offered.

In the contact us page, viewers can input their information by filling up a form. The company shall contact them after the form is submitted. The reset buittons allows the viewer to clear all the fields in the form itself and enter information on a clean slate.


Technologies Used
Bootstrap is used in this project.


Contact form:
Go to the "Contact Us" page
It's mandatory to fill up certain fields and viewers cannot leave them blank as indicated in the input tags with "required".
Try to submit the form with an invalid email address and verify that a relevant error message appears
Try to submit the form with all inputs valid and verify that a success message appears.


While testing, at times, when the screen is adjusted to different sizes, the elements may not be properly aligned. Need to optimise the website further


Credits
Content
The text for this website is generated from ChatGPT.
Media
The photos used in this site were obtained from google search
Acknowledgements
I received inspiration for this project from previous lesson conducted by lecturer from Bells Lab